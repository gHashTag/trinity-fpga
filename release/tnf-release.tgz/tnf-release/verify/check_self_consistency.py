#!/usr/bin/env python3
"""Does a document agree with itself?

Every gate here compares a document against something else -- data files, the
tree, a sibling artefact. None of them compares a document against itself, and
the paper carried three different counts of its own retractions in three places:
four in the roadmap, eleven in the abstract, sixteen in the method section.

A number a document states about its own contents is checkable against those
contents, and nothing was checking it. This does that: it counts the retraction
marks in the body and requires every sentence claiming a retraction count to
agree with the count.

The class generalises past this one number -- any 'we do N of X' where X is
countable in the same file belongs here.
"""
import re, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
PAPER = ROOT / "research" / "arxiv_tnf" / "tnf_paper.tex"
WORDS = {"one":1,"two":2,"three":3,"four":4,"five":5,"six":6,"seven":7,"eight":8,
         "nine":9,"ten":10,"eleven":11,"twelve":12,"thirteen":13,"fourteen":14,
         "fifteen":15,"sixteen":16,"seventeen":17,"eighteen":18,"nineteen":19,
         "twenty":20}

t = PAPER.read_text()
fails = []

# 1. count the marks the body actually carries
# NOTE (2026-08-12): this pattern originally omitted the ACTIVE voice. Three
# retractions were added in later iterations phrased "we withdraw it" and "that
# sentence is now retired", the counter did not see them, and the paper's
# self-reported retraction count silently drifted BELOW the truth while this
# gate stayed green. A counter that only recognises one phrasing is a counter
# you can evade by writing normally.
MARK = re.compile(r"\\paragraph\{[^}]*[Ww]ithdrawn[^}]*\}"
                  r"|(?<!are )(?<!not )\bis withdrawn\b"
                  r"|\bare withdrawn\b|\bis retracted\b"
                  r"|\bwe withdraw\b|\bwe retract\b"
                  r"|\b(?:is|are|was|were) now retired\b|\bretired that sentence\b")
# A \paragraph heading announcing a withdrawal and the sentence closing it are
# ONE retraction, not two. A summary sentence counting the retractions is not a
# retraction at all. Counting raw marks gave eight where the body holds five,
# which is the same class of error the gate exists to catch.
raw = [(m.start(), m.group(0)) for m in MARK.finditer(t)]
marks, last_head = [], -10**9
for pos, txt in raw:
    if re.search(r"(?:claims?|retractions?)\s+[^.]{0,60}(?:retracted|falsified)", 
                 t[max(0,pos-160):pos+60], re.I) and "paragraph" not in txt:
        continue                       # this is the summary sentence itself
    if txt.startswith("\\paragraph"):
        marks.append(pos); last_head = pos; continue
    if pos - last_head < 2000:
        continue                       # closes a heading already counted
    marks.append(pos)
marked = len(marks)

# 2. every sentence claiming a count must agree, EXCEPT ones explicitly scoped
#    to the campaign rather than to this document
# "marked in place" is the abstract's own phrasing and the original pattern did
# not include it, so the single most-read sentence in the document stating a
# retraction count was the one sentence this gate never checked.
# Two word orders occur and only one was matched. "Sixteen claims are
# retracted" was caught; "we have retracted sixteen claims" was not, and a
# mutation test proved a wrong count in that order passes silently. Same class
# of hole as the passive-voice one above: one phrasing recognised.
CLAIM = re.compile(
    r"([A-Z][a-z]+|\d+)\s+(?:of our own\s+)?"
    r"(?:retractions?|claims?)\s+[^.]{0,90}?"
    r"(?:retracted|withdrawn|falsified|marked in place)[^.]*\."
    r"|(?:retracted|withdrawn|falsified)\s+([a-z]+|\d+)\s+"
    r"(?:of our own\s+)?(?:retractions?|claims?)[^.]*\.", re.I)
for m in CLAIM.finditer(t):
    s = re.sub(r"\s+", " ", m.group(0))
    tok = (m.group(1) or m.group(2) or "").lower()
    n = WORDS.get(tok, int(tok) if tok.isdigit() else None)
    if n is None: continue
    if "during the campaign" in s or "during this work" in s or "during the work" in s:
        continue        # scoped to the campaign, not to what this file marks
    if n != marked:
        fails.append(f"claims {n} retractions but the body marks {marked}: {s[:100]}")

# The abstract is the most-read paragraph and this gate did not read it. It
# carried "Five retractions" while the body carried ten, "twenty formats" while
# the table held twenty-five, and figures from a superseded harness -- a flat
# contradiction on page one that survived because the counter scanned only the
# body. It also ran 2,010 characters against arXiv's 1,920 limit.
_i, _j = t.find(r"\begin{abstract}"), t.find(r"\end{abstract}")
if _i > 0 and _j > _i:
    _ab = re.sub(r"\s+", " ", t[_i + len(r"\begin{abstract}"):_j]).strip()
    if len(_ab) > 1920:
        fails.append(f"abstract is {len(_ab)} characters; arXiv allows 1920")
    # The abstract phrases it "N retractions are marked in place below", which
    # CLAIM does not match: CLAIM requires retracted/withdrawn/falsified and the
    # abstract says "marked". That mismatch is exactly why the contradiction
    # survived -- the gate looked, and its pattern did not fit the sentence.
    _ABCLAIM = re.compile(r"([A-Z][a-z]+|\d+)\s+retractions?\s+are\s+marked", re.I)
    for _m in list(CLAIM.finditer(_ab)) + list(_ABCLAIM.finditer(_ab)):
        _tok = _m.group(1).lower()
        _n = WORDS.get(_tok, int(_tok) if _tok.isdigit() else None)
        if _n is not None and _n != marked:
            fails.append(f"abstract claims {_n} retractions but the body marks {marked}")
    print(f"abstract: {len(_ab)} characters of 1920")

print(f"retraction marks in the body: {marked}")
if fails:
    print(f"\nFAIL: {len(fails)} self-inconsistency(ies)\n")
    for f in fails: print(f"  {f}")
    sys.exit(1)
print("OK: every stated count agrees with what the document contains")
